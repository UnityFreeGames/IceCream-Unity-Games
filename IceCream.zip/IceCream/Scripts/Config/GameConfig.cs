﻿
namespace Config
{
    public static class GameConfig
    {
        public static float SMOOTHNESS = 0.15f;
        public static float MACHINE_SPEED = 2f;
    }
}
