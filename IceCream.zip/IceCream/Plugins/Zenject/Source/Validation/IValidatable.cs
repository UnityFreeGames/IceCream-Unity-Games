namespace Zenject
{
    public interface IValidatable
    {
        void Validate();
    }
}
